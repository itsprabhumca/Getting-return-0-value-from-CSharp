﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsAppDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnChildApp_Click(object sender, EventArgs e)
        {
            Process _process = new Process();
            
            ProcessStartInfo start = new ProcessStartInfo(@"<<Console APP Path>>\ChildAppDemo.exe");
            start.Arguments = txtName.Text;
            start.WindowStyle = ProcessWindowStyle.Normal;
            start.UseShellExecute = false;
            _process.StartInfo = start;
            _process = Process.Start(start);

            if(_process.HasExited)
            {
                MessageBox.Show(string.Format("Child Program Exited with {0} at {1}",_process.ExitCode,_process.ExitTime));
            }
            else
            {
                MessageBox.Show("Error Occurred!");
            }
        }
    }
}
