﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChildAppDemo
{
    class Program
    {
        static int Main(string[] args)
        {
            Console.WriteLine(args[0]);
            Console.ReadKey();
            return 0;
        }
    }
}
